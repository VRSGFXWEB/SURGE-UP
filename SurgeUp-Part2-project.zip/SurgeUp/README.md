# Surge Up Beta - Part 2

Isi:
- Loading screen baru (animasi, tips, progress) sebelum menu dan sebelum pertandingan.
- Lobby baru mengikuti desain foto: menu kiri (BERANDA, STORE, KARAKTER, SENJATA, VAULT, EVENT, RANK),
  banner SURGEUP, chat GLOBAL / TIM / GUILD, panel TEMAN, kartu SQUAD, tombol MULAI.
- Latar 3D = map training (map_ep_73.glb). Karakter berdiri di lantai map, tanpa alas bulat.
- Teman: TAMBAH lewat ID, permintaan teman, status Online/Offline.
- Mabar: UNDANG teman online, banner UNDANGAN SQUAD (TERIMA / X), room 2 orang, kode room 5 huruf,
  status MENUNGGU TEMAN SIAP / TEMAN SIAP, tombol SIAP untuk anggota, MULAI untuk host.
- Room native: BUAT ROOM, GABUNG pakai kode, pilih map (TRAINING / ARENA), chat TIM di dalam room.
- Musik lobby original (dibuat sendiri), otomatis jalan di lobby, bisa dimatikan di Pengaturan.
- Chat 7 menit, filter kata terlarang + ban otomatis 2 jam, layar ban, notifikasi admin + banner 5 detik.

Mode yang benar-benar jalan: SOLO vs bot (map training / arena) dan 1v1 online lawan teman
(memakai netcode game yang sudah ada). 2v2 belum ada karena inti game hanya mendukung 1 lawan.

## Build
A) AndroidIDE: Open project > tunggu Gradle sync > Build > Build APK.
B) GitHub (tanpa PC): upload semua isi folder ini (termasuk .github) ke repo baru,
   tab Actions > Build APK > Run workflow > download artifact SurgeUp-debug-apk.
