package com.app.surge.up

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/** Latar 3D lobby: map training + karakter pemain berdiri di lantai map (tanpa alas bulat). */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun Lobby3D(playersJson: String) {
    val holder = remember { arrayOfNulls<WebView>(1) }
    val ready = remember { mutableStateOf(false) }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            val loader = WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(c))
                .build()
            val w = WebView(c)
            w.setBackgroundColor(android.graphics.Color.BLACK)
            w.settings.javaScriptEnabled = true
            w.settings.domStorageEnabled = true
            w.webChromeClient = WebChromeClient()
            w.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val u = request?.url ?: return null
                    return loader.shouldInterceptRequest(u)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    ready.value = true
                }
            }
            w.loadUrl("https://appassets.androidplatform.net/assets/lobby3d.html")
            holder[0] = w
            w
        }
    )

    LaunchedEffect(playersJson, ready.value) {
        if (ready.value) {
            holder[0]?.evaluateJavascript(
                "window.setPlayers && window.setPlayers(" + JSONObject.quote(playersJson) + ")", null
            )
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            holder[0]?.destroy()
            holder[0] = null
        }
    }
}
