package com.app.surge.up

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun playersJson(room: RoomState?): String {
    val a = JSONArray()
    a.put(JSONObject().put("n", Session.name))
    val mate = room?.members?.firstOrNull { it.id != Session.id }
    if (mate != null) a.put(JSONObject().put("n", mate.name))
    return a.toString()
}

@Composable
fun LobbyScreen(onStart: (Launch) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var dlg by remember { mutableStateOf("") }
    var chatTab by remember { mutableStateOf("GLOBAL") }
    val room = UiState.room
    val me = Session.id
    val invite = UiState.invite
    val banner = UiState.banner

    LaunchedEffect(Unit) { Music.start(ctx) }
    DisposableEffect(Unit) {
        UiState.lobbyActive = true
        onDispose { UiState.lobbyActive = false }
    }

    // sinkron teman, room, undangan; mulai pertandingan saat host menekan MULAI
    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            Social.pollRoom()
            Social.pollInvites()
            val st = UiState.room
            if (st != null && st.members.size == 2 && st.go.isNotEmpty() && st.go != Social.lastGo && Social.goFresh(st.go)) {
                Social.lastGo = st.go
                val opp = st.members.firstOrNull { it.id != me }
                if (opp != null) onStart(Launch(opp.id, opp.name, st.map))
            }
            if (n % 5 == 0) {
                val f = Social.loadFriends()
                if (f != null) UiState.friends = f
                val r = Social.loadReqs()
                if (r != null) UiState.reqs = r
            }
            n++
            delay(2000L)
        }
    }
    // chat global
    LaunchedEffect(Unit) {
        while (true) {
            val m = Chat.fetch()
            if (m != null) UiState.messages = m
            delay(3000L)
        }
    }
    // chat tim (di dalam room)
    LaunchedEffect(room?.code) {
        val code = room?.code
        if (code == null) {
            UiState.teamMessages = emptyList()
        } else {
            while (true) {
                val m = Chat.fetch("rooms/" + code + "/chat")
                if (m != null) UiState.teamMessages = m
                delay(3000L)
            }
        }
    }
    LaunchedEffect(banner) {
        if (banner != null) {
            delay(5000L)
            if (UiState.banner === banner) UiState.banner = null
        }
    }
    LaunchedEffect(UiState.toast) {
        if (UiState.toast.isNotEmpty()) {
            delay(2200L)
            UiState.toast = ""
        }
    }

    val doStart: () -> Unit = {
        scope.launch {
            val st = UiState.room
            if (st == null || st.members.size < 2) {
                onStart(Launch("", "", st?.map ?: Social.MAP_TRAIN))
            } else if (st.host == me) {
                val other = st.members.firstOrNull { it.id != me }
                if (other == null || !other.ready) {
                    UiState.toast = "Tunggu teman siap dulu."
                } else if (Social.hostStart()) {
                    onStart(Launch(other.id, other.name, st.map))
                } else {
                    UiState.toast = "Gagal memulai. Coba lagi."
                }
            } else {
                val mine = st.members.firstOrNull { it.id == me }
                Social.setReady(!(mine?.ready ?: false))
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (!UiState.gameOn) Lobby3D(playersJson(room))
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xE6000000), Color(0x22000000), Color(0x22000000), Color(0xE6000000)))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent, Color(0x99000000)))))

        TopBar(
            dlg = { dlg = it }
        )

        // kolom kiri: navigasi + banner + chat
        Row(Modifier.fillMaxHeight().padding(top = 64.dp, bottom = 10.dp)) {
            NavColumn()
            Spacer(Modifier.width(8.dp))
            Column(Modifier.width(330.dp).fillMaxHeight()) {
                BannerCard()
                Spacer(Modifier.height(8.dp))
                ChatPanel(chatTab, { chatTab = it }, Modifier.weight(1f).fillMaxWidth())
            }
        }

        // kolom kanan: teman + squad + mulai
        Column(
            Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(300.dp).padding(top = 64.dp, bottom = 10.dp, end = 10.dp)
        ) {
            TeamPanel(room, { dlg = "add" }, Modifier.weight(1f).fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            SquadCard(room, me) { dlg = "room" }
            Spacer(Modifier.height(8.dp))
            StartButton(room, me, doStart)
        }

        if (invite != null) {
            InviteBanner(
                invite,
                Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
                onAccept = {
                    scope.launch {
                        val err = Social.acceptInvite(invite)
                        UiState.toast = if (err.isEmpty()) "Masuk ke room " + invite.fromName else err
                    }
                },
                onDecline = { scope.launch { Social.declineInvite(invite) } }
            )
        } else if (banner != null) {
            Row(
                Modifier.align(Alignment.TopCenter).padding(top = 8.dp).width(380.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color(0xF0140A0E))
                    .border(1.dp, CRed, RoundedCornerShape(8.dp)).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar("!", 34)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(banner.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                    Text(banner.body, color = CSoft, fontSize = 12.sp, maxLines = 2)
                }
            }
        }

        if (UiState.toast.isNotEmpty()) {
            Text(
                UiState.toast, color = Color.White, fontSize = 13.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)
                    .clip(RoundedCornerShape(6.dp)).background(Color(0xE6000000)).padding(horizontal = 14.dp, vertical = 7.dp)
            )
        }
    }

    when (dlg) {
        "add" -> AddFriendDialog { dlg = "" }
        "room" -> RoomDialog { dlg = "" }
        "reqs" -> ReqsDialog { dlg = "" }
        "mail" -> MailDialog { dlg = "" }
        "settings" -> SettingsDialog { dlg = "" }
        else -> {}
    }
}

// ---------- Bar atas ----------
@Composable
fun TopBar(dlg: (String) -> Unit) {
    val toastReq = UiState.reqs.size
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier.clip(SlantShape(12f)).background(CPanel).border(1.dp, CRed, SlantShape(12f))
                .padding(start = 18.dp, end = 26.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(Session.name, 40)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(Session.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, maxLines = 1)
                Text("ID " + Session.id, color = CSoft, fontSize = 11.sp)
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text("Lv. 1", color = CGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Box(Modifier.width(90.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF2A2A32))) {
                    Box(Modifier.width(6.dp).fillMaxHeight().background(CGold))
                }
            }
        }
        Spacer(Modifier.width(14.dp))
        Pill("99999")
        Spacer(Modifier.width(8.dp))
        Pill("99999")
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.clip(SlantShape(12f)).background(CPanel).padding(horizontal = 18.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TopIcon(Icons.Filled.AccountBox, false) { UiState.toast = "Dompet segera hadir" }
            TopIcon(Icons.Filled.AccountCircle, toastReq > 0) { dlg("reqs") }
            TopIcon(Icons.Filled.Email, UiState.notifs.isNotEmpty()) { dlg("mail") }
            TopIcon(Icons.Filled.Settings, false) { dlg("settings") }
        }
    }
}

@Composable
fun Pill(value: String) {
    Text(
        value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(CPanel)
            .border(1.dp, CLine, RoundedCornerShape(6.dp)).padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
fun TopIcon(icon: ImageVector, dot: Boolean, onClick: () -> Unit) {
    Box(Modifier.padding(horizontal = 6.dp).clickable { onClick() }.padding(6.dp)) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
        if (dot) Box(Modifier.align(Alignment.TopEnd).size(8.dp).clip(CircleShape).background(CRed))
    }
}

// ---------- Menu kiri ----------
@Composable
fun NavColumn() {
    Column(Modifier.width(112.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        NavItem(Icons.Filled.Home, "BERANDA", true, false) { }
        NavItem(Icons.Filled.ShoppingCart, "STORE", false, true) { UiState.toast = "Store segera hadir" }
        NavItem(Icons.Filled.Person, "KARAKTER", false, false) { UiState.toast = "Karakter segera hadir" }
        NavItem(Icons.Filled.Build, "SENJATA", false, false) { UiState.toast = "Senjata segera hadir" }
        NavItem(Icons.Filled.Lock, "VAULT", false, false) { UiState.toast = "Vault segera hadir" }
        NavItem(Icons.Filled.DateRange, "EVENT", false, true) { UiState.toast = "Event segera hadir" }
        NavItem(Icons.Filled.Star, "RANK", false, false) { UiState.toast = "Rank segera hadir" }
    }
}

@Composable
fun NavItem(icon: ImageVector, label: String, on: Boolean, dot: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(SlantShape(10f))
            .background(if (on) Brush.horizontalGradient(listOf(CRed, CRedDark)) else Brush.horizontalGradient(listOf(Color(0x99000000), Color(0x00000000))))
            .clickable { onClick() }.padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            if (dot) Box(Modifier.align(Alignment.TopEnd).size(7.dp).clip(CircleShape).background(CRed))
        }
        Spacer(Modifier.width(8.dp))
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun BannerCard() {
    Box(
        Modifier.fillMaxWidth().height(78.dp).clip(RoundedCornerShape(8.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B0B10), Color(0xFF3A0A14), Color(0xFF8A1424))))
            .border(1.dp, CRed, RoundedCornerShape(8.dp)).padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Column(Modifier.align(Alignment.CenterStart)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("SURGE", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                Text("UP", color = CRed, fontSize = 30.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
            }
            Text("PLAY . FIGHT . BE THE BEST", color = CSoft, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ---------- Chat ----------
@Composable
fun ChatPanel(tab: String, onTab: (String) -> Unit, modifier: Modifier) {
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val room = UiState.room
    val msgs = if (tab == "TIM") UiState.teamMessages else UiState.messages
    val listState = rememberLazyListState()
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    LaunchedEffect(msgs.size, tab) {
        if (msgs.isNotEmpty()) listState.scrollToItem(msgs.size - 1)
    }

    Column(
        modifier.clip(RoundedCornerShape(8.dp)).background(CPanel).border(1.dp, CLine, RoundedCornerShape(8.dp))
    ) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF0E0E13))) {
            ChatTab("GLOBAL", tab == "GLOBAL") { onTab("GLOBAL") }
            ChatTab("TIM", tab == "TIM") { onTab("TIM") }
            ChatTab("GUILD", tab == "GUILD") { onTab("GUILD") }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp)) {
            if (tab == "GUILD") {
                Text("Guild segera hadir.", color = CSoft, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center))
            } else if (tab == "TIM" && room == null) {
                Text("Masuk room dulu untuk chat tim.", color = CSoft, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center))
            } else {
                LazyColumn(Modifier.fillMaxSize(), state = listState) {
                    items(msgs, key = { it.key }) { m ->
                        Row(Modifier.padding(vertical = 4.dp)) {
                            Avatar(m.name, 30, nameColor(m.id))
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Row {
                                    Text(m.name, color = nameColor(m.id), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(Modifier.width(6.dp))
                                    Text(fmt.format(Date(m.t)), color = CSoft, fontSize = 10.sp)
                                }
                                Text(
                                    m.text, color = Color.White, fontSize = 13.sp,
                                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFF1B1B22)).padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
        if (status.isNotEmpty()) Text(status, color = Color(0xFFFF7A8A), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp))
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Field(input, { if (it.length <= 100) input = it }, "Ketik pesan...", Modifier.weight(1f))
            Spacer(Modifier.width(6.dp))
            Box(
                Modifier.clip(SlantShape(8f)).background(if (busy) CRedDark else CRed)
                    .clickable(enabled = !busy && tab != "GUILD" && !(tab == "TIM" && room == null)) {
                        val clean = input.replace(Regex("\\s+"), " ").trim()
                        if (clean.isNotEmpty()) {
                            busy = true
                            status = ""
                            scope.launch {
                                val path = if (tab == "TIM" && room != null) "rooms/" + room.code + "/chat" else "chat/global"
                                val b = Moderation.checkBan(Session.id)
                                if (b != null) {
                                    UiState.ban = b
                                } else if (Moderation.hasBad(clean)) {
                                    UiState.ban = Moderation.autoBan(Session.id)
                                } else if (Chat.send(Session.id, Session.name, clean, path)) {
                                    input = ""
                                    val m = Chat.fetch(path)
                                    if (m != null) {
                                        if (tab == "TIM") UiState.teamMessages = m else UiState.messages = m
                                    }
                                } else {
                                    status = "Pesan gagal terkirim."
                                }
                                busy = false
                            }
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Send, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
fun ChatTab(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.weight(1f).background(if (on) CRed else Color.Transparent).clickable { onClick() }.padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (on) Color.White else CSoft, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 12.sp)
    }
}

// ---------- Panel teman ----------
@Composable
fun TeamPanel(room: RoomState?, onAdd: () -> Unit, modifier: Modifier) {
    val scope = rememberCoroutineScope()
    val friends = UiState.friends
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).background(CPanel).border(1.dp, CLine, RoundedCornerShape(8.dp)).padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("TEMAN", color = Color.White, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 16.sp)
            Spacer(Modifier.weight(1f))
            Text(friends.size.toString(), color = CGold, fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Row(
                Modifier.fillMaxWidth().clip(SlantShape(14f)).background(CGold).clickable { onAdd() }.padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = Color(0xFF1A1205), modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(4.dp))
                Text("TAMBAH", color = Color(0xFF1A1205), fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(4.dp))
        if (friends.isEmpty()) {
            Text("Belum ada teman. Tekan TAMBAH lalu masukkan ID teman.", color = CSoft, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(friends, key = { it.id }) { f ->
                    val inRoom = room != null && room.members.any { it.id == f.id }
                    FriendRow(f, inRoom) {
                        scope.launch { UiState.toast = Social.inviteFriend(f) }
                    }
                }
            }
        }
    }
}

@Composable
fun FriendRow(f: Friend, inRoom: Boolean, onInvite: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box {
            Avatar(f.name, 42, nameColor(f.id))
            Text(
                "LV1", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black,
                modifier = Modifier.align(Alignment.BottomCenter).clip(RoundedCornerShape(3.dp)).background(Color(0xCC000000)).padding(horizontal = 4.dp)
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (f.online) CGreen else Color(0xFF6A6A78)))
                Spacer(Modifier.width(5.dp))
                Text(if (f.online) "Online" else "Offline", color = if (f.online) CGreen else CSoft, fontSize = 11.sp)
            }
        }
        if (inRoom) {
            Text(
                "SQUAD", color = Color.White, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 12.sp,
                modifier = Modifier.clip(SlantShape(8f)).background(Color(0xFF26262E)).padding(horizontal = 14.dp, vertical = 6.dp)
            )
        } else {
            Text(
                "UNDANG", color = if (f.online) Color(0xFF1A1205) else CSoft, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 12.sp,
                modifier = Modifier.clip(SlantShape(8f)).background(if (f.online) CGold else Color(0xFF1B1B22))
                    .clickable { onInvite() }.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

// ---------- Kartu squad + MULAI ----------
@Composable
fun SquadCard(room: RoomState?, me: String, onOpen: () -> Unit) {
    val mate = room?.members?.firstOrNull { it.id != me }
    val mateReady = mate != null && (mate.id == room?.host || mate.ready)
    val sub = if (room == null) {
        "TAP UNTUK BUAT ROOM"
    } else if (mate == null) {
        "KODE " + room.code + " \u00B7 MENUNGGU TEMAN"
    } else if (mateReady) {
        "TEMAN SIAP"
    } else {
        "MENUNGGU TEMAN SIAP"
    }
    Row(
        Modifier.fillMaxWidth().height(86.dp).clip(RoundedCornerShape(8.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B0B10), Color(0xFF2E0A12))))
            .border(1.dp, CRed, RoundedCornerShape(8.dp)).clickable { onOpen() }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(54.dp).clip(RoundedCornerShape(6.dp)).background(Brush.verticalGradient(listOf(Color(0xFF3A3A44), Color(0xFF15151B)))),
            contentAlignment = Alignment.Center
        ) {
            Text(room?.map?.take(1) ?: "S", color = CRed, fontWeight = FontWeight.Black, fontSize = 24.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("SQUAD 1VS1", color = Color.White, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 18.sp)
            Text(sub, color = if (sub == "TEMAN SIAP") CGreen else CSoft, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
fun StartButton(room: RoomState?, me: String, onClick: () -> Unit) {
    val isGuest = room != null && room.host != me && room.members.size >= 2
    val mine = room?.members?.firstOrNull { it.id == me }
    val label = if (isGuest) (if (mine?.ready == true) "BATAL SIAP" else "SIAP") else "MULAI"
    Box(
        Modifier.fillMaxWidth().height(78.dp).clip(SlantShape(22f))
            .background(Brush.horizontalGradient(listOf(CRedDark, CRed, Color(0xFFFF4A5E))))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 36.sp)
    }
}

@Composable
fun InviteBanner(inv: Invite, modifier: Modifier, onAccept: () -> Unit, onDecline: () -> Unit) {
    Row(
        modifier.width(430.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xF0140A0E))
            .border(1.dp, CRed, RoundedCornerShape(8.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(inv.fromName, 40, nameColor(inv.fromId))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("UNDANGAN SQUAD", color = CGold, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 12.sp)
            Text(inv.fromName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            Text("mengajak masuk squad (maks 2 orang)", color = CSoft, fontSize = 11.sp)
        }
        GoldSlantButton("TERIMA", Modifier) { onAccept() }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.clip(CircleShape).background(Color(0xFF26262E)).clickable { onDecline() }.padding(8.dp)) {
            Icon(Icons.Filled.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
    }
}

// ---------- Dialog ----------
@Composable
fun Sheet(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(480.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF0E0E13))
                .border(1.dp, CRed, RoundedCornerShape(10.dp)).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color.White, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 18.sp, modifier = Modifier.weight(1f))
                Box(Modifier.clip(CircleShape).clickable { onClose() }.padding(6.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun AddFriendDialog(onClose: () -> Unit) {
    var id by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Sheet("TAMBAH TEMAN", onClose) {
        Text("Masukkan ID pemain teman kamu. ID kamu: " + Session.id, color = CSoft, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Field(id, { if (it.length <= 10) id = it.filter { c -> c.isDigit() } }, "ID teman", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        RedButton(if (busy) "..." else "KIRIM PERMINTAAN", Modifier.fillMaxWidth(), enabled = !busy) {
            busy = true
            scope.launch {
                msg = Social.sendFriendReq(id)
                busy = false
            }
        }
        if (msg.isNotEmpty()) Text(msg, color = CGold, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun ReqsDialog(onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    Sheet("PERMINTAAN TEMAN", onClose) {
        val list = UiState.reqs
        if (list.isEmpty()) Text("Tidak ada permintaan.", color = CSoft, fontSize = 13.sp)
        for (r in list) {
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(r.name, 36, nameColor(r.fromId))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("ID " + r.fromId, color = CSoft, fontSize = 11.sp)
                }
                GoldSlantButton("TERIMA", Modifier) {
                    scope.launch {
                        Social.acceptReq(r.fromId)
                        UiState.reqs = UiState.reqs.filter { it.fromId != r.fromId }
                        val f = Social.loadFriends()
                        if (f != null) UiState.friends = f
                    }
                }
                Spacer(Modifier.width(6.dp))
                Box(Modifier.clip(CircleShape).background(Color(0xFF26262E)).clickable {
                    scope.launch {
                        Social.declineReq(r.fromId)
                        UiState.reqs = UiState.reqs.filter { it.fromId != r.fromId }
                    }
                }.padding(8.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun MailDialog(onClose: () -> Unit) {
    Sheet("PESAN DARI ADMIN", onClose) {
        val list = UiState.notifs
        if (list.isEmpty()) Text("Belum ada pesan.", color = CSoft, fontSize = 13.sp)
        for (n in list.reversed()) {
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text(n.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(n.body, color = CSoft, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SettingsDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var music by remember { mutableStateOf(Session.music) }
    Sheet("PENGATURAN", onClose) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Musik lobby", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            RedButton(if (music) "ON" else "OFF") {
                music = !music
                Session.music = music
                if (music) Music.start(ctx) else Music.pause()
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Surge Up Beta \u00B7 ID " + Session.id, color = CSoft, fontSize = 12.sp)
    }
}

@Composable
fun RoomDialog(onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val room = UiState.room
    val me = Session.id
    var join by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var selMap by remember { mutableStateOf(Social.MAP_TRAIN) }
    val map = room?.map ?: selMap
    val hasMate = room != null && room.members.size >= 2

    Sheet("ROOM", onClose) {
        Text("MAP", color = CSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
            MapChip("TRAINING", "Menara Jam \u00B7 solo vs bot", map == Social.MAP_TRAIN, !hasMate) {
                if (room == null) selMap = Social.MAP_TRAIN else scope.launch { Social.setMap(Social.MAP_TRAIN) }
            }
            MapChip("ARENA", "Arena utama \u00B7 solo & online", map == Social.MAP_ARENA, true) {
                if (room == null) selMap = Social.MAP_ARENA else scope.launch { Social.setMap(Social.MAP_ARENA) }
            }
        }
        if (hasMate && map == Social.MAP_TRAIN) {
            Text("Map TRAINING hanya untuk solo. Pilih ARENA untuk bermain online.", color = CGold, fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
        if (room == null) {
            RedButton("BUAT ROOM", Modifier.fillMaxWidth()) {
                scope.launch {
                    val c = Social.createRoom(selMap)
                    msg = if (c == null) "Gagal membuat room." else "Room dibuat: " + c
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("ATAU GABUNG PAKAI KODE", color = CSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Field(join, { if (it.length <= 5) join = it.uppercase() }, "KODE 5 HURUF", Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                GoldSlantButton("GABUNG", Modifier) {
                    scope.launch { msg = Social.joinRoom(join).ifEmpty { "Berhasil masuk room." } }
                }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("KODE ROOM", color = CSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Text(room.code, color = CGold, fontSize = 26.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                RedButton("SALIN") {
                    clip.setText(AnnotatedString(room.code))
                    msg = "Kode disalin."
                }
            }
            Spacer(Modifier.height(8.dp))
            for (m in room.members) {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(m.name, 34, nameColor(m.id))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.name + if (m.id == me) " (kamu)" else "", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(if (m.id == room.host) "HOST" else "ANGGOTA", color = CSoft, fontSize = 11.sp)
                    }
                    Text(
                        if (m.id == room.host) "SIAP" else if (m.ready) "SIAP" else "BELUM",
                        color = if (m.id == room.host || m.ready) CGreen else CSoft, fontWeight = FontWeight.Black, fontSize = 12.sp
                    )
                }
            }
            if (room.members.size < 2) {
                Text("Undang teman dari panel TEMAN (tombol UNDANG) atau bagikan kode ini.", color = CSoft, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
            }
            Spacer(Modifier.height(6.dp))
            RedButton("KELUAR ROOM", Modifier.fillMaxWidth()) {
                scope.launch {
                    Social.leaveRoom()
                    msg = "Keluar dari room."
                }
            }
        }
        if (msg.isNotEmpty()) Text(msg, color = CGold, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun MapChip(title: String, sub: String, on: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.width(210.dp).clip(RoundedCornerShape(8.dp))
            .background(if (on) Color(0xFF2A0C14) else Color(0xFF15151B))
            .border(1.5.dp, if (on) CRed else CLine, RoundedCornerShape(8.dp))
            .clickable(enabled = enabled) { onClick() }.padding(10.dp)
    ) {
        Text(title, color = if (enabled) Color.White else CSoft, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 16.sp)
        Text(sub, color = CSoft, fontSize = 11.sp)
    }
}
